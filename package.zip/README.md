# lambda_mysql
Simple lambda function which queries mysql db
